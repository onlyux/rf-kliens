﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proba
{
    public class Termekek
    {
        public string Bvin { get; set; }
        public string Sku { get; set; }
        public string ProductName {  get; set; }
        public int SitePrice { get; set; }
    }
}

