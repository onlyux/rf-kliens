﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proba
{
    public class Termekchoices
    {
        public string Name { get; set; }
        public string Bvin {  get; set; }
        public int StoreId { get; set; }
        //public string OptionType { get; set; }
    }
}
